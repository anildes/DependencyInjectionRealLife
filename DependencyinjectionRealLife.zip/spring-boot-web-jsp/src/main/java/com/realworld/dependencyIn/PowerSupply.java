package com.realworld.dependencyIn;

import org.springframework.stereotype.Component;

@Component

public class PowerSupply {

}
